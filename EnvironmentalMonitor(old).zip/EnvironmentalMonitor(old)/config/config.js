module.exports = {
    HTMLDirs:[
        "login",
        "monitorpage",
    ],
}